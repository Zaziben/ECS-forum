import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

ecs = boto3.client('ecs')
ec2 = boto3.client('ec2')
cloudfront = boto3.client('cloudfront')

DISTRIBUTION_ID = os.environ['DISTRIBUTION_ID']
CLUSTER_NAME = os.environ['CLUSTER_NAME']

def get_task_ip(task_arn):
    """Get the public DNS name of a running ECS task."""
    response = ecs.describe_tasks(
        cluster=CLUSTER_NAME,
        tasks=[task_arn]
    )

    tasks = response.get('tasks', [])
    if not tasks:
        raise Exception(f"Task {task_arn} not found")

    task = tasks[0]

    attachments = task.get('attachments', [])
    eni_id = None
    for attachment in attachments:
        if attachment['type'] == 'ElasticNetworkInterface':
            for detail in attachment['details']:
                if detail['name'] == 'networkInterfaceId':
                    eni_id = detail['value']
                    break

    if not eni_id:
        raise Exception("No ENI found for task")

    response = ec2.describe_network_interfaces(
        NetworkInterfaceIds=[eni_id]
    )

    interfaces = response.get('NetworkInterfaces', [])
    if not interfaces:
        raise Exception(f"ENI {eni_id} not found")

    association = interfaces[0].get('Association', {})
    public_dns = association.get('PublicDnsName')

    if not public_dns:
        raise Exception("No public DNS name found on ENI")

    return public_dns

def update_cloudfront_origin(new_ip):
    """Update the CloudFront distribution origin to point at the new task IP."""
    # Get current distribution config - required to get ETag for update
    response = cloudfront.get_distribution_config(Id=DISTRIBUTION_ID)
    config = response['DistributionConfig']
    etag = response['ETag']

    # Update the origin domain name
    origins = config['Origins']['Items']
    for origin in origins:
        if origin['Id'] == 'phpbb-ecs-origin':
            old_ip = origin['DomainName']
            origin['DomainName'] = new_ip
            logger.info(f"Updating CloudFront origin from {old_ip} to {new_ip}")
            break

    # Push the update
    cloudfront.update_distribution(
        Id=DISTRIBUTION_ID,
        DistributionConfig=config,
        IfMatch=etag
    )

    logger.info(f"CloudFront origin updated to {new_ip}")


def handler(event, context):
    """
    EventBridge handler - fires when ECS task reaches RUNNING state.
    Grabs the task's public IP and updates the CloudFront origin.
    """
    logger.info(f"Event received: {event}")

    detail = event.get('detail', {})
    task_arn = detail.get('taskArn')
    last_status = detail.get('lastStatus')
    cluster_arn = detail.get('clusterArn', '')

    # Only process tasks from our cluster
    if CLUSTER_NAME not in cluster_arn:
        logger.info(f"Ignoring task from different cluster: {cluster_arn}")
        return

    if last_status != 'RUNNING':
        logger.info(f"Ignoring task with status: {last_status}")
        return

    logger.info(f"Processing task: {task_arn}")

    try:
        ip = get_task_ip(task_arn)
        logger.info(f"Task IP: {ip}")
        update_cloudfront_origin(ip)
        logger.info("Done")
        return {'statusCode': 200, 'ip': ip}
    except Exception as e:
        logger.error(f"Error: {e}")
        raise
